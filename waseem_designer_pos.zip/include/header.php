
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--favicon-->
  <link rel="icon" href="images/favicon-32x32.png" type="image/png" />
  
  <title>Ajmal Batteries</title>
   <?php include("include/css_links.php") ?>
</head>

<body>
  <!--wrapper-->
  <div class="wrapper">
     <?php include("include/head.php") ?>
      <?php include("include/menu.php") ?>
      <div class="page-wrapper">