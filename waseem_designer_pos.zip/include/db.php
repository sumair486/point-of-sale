<?php
  $server_host = 'localhost';
  $server_username = 'root';
  $server_password = '';
  $server_dbname = 'waseem_designer_pos_db';
  $connection = mysqli_connect($server_host,$server_username,$server_password,$server_dbname);
?>