<?php 
    include('../../include/db.php'); 
?>