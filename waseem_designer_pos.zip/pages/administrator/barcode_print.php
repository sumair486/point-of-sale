<?php include("include/header.php") ?>
<div class="container-fluid">

     <div class="row">
     <div class="col-md-12 mt-5">
     	<center><h4>Generate Product's Bar Code</h4>
     	 <a href="bar_code_ajax.php" Value="" class="Data_Ajax title btn btn-dark btn-sm bg-primary"  title="Print">Print Bar Code</a>
     </div>

     </div>
	</div>
<?php include("include/footer.php") ?>