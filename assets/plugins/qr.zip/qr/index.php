<!DOCTYPE html>
<html style="overflow: hidden;">
<head>
	<title>UTS</title>
  <link rel="shortcut icon" href="../../images/logo.png" type="image/png">
	<link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body style="background-image: linear-gradient(red, blue);">
<div class="row mt-5">
	<div class="col-md-12 mt-5 text-center">
	<div style="font-size: 100px; color: white">4<i class="fa fa-question-circle fa-spin"></i>4</div>

	<div class="text-white">
		The page you are looking for was not found
	</div>
</div>
</div>
</body>
</html>
<script src="../../plugins/bootstrap/js/bootstrap.min.js"></script>